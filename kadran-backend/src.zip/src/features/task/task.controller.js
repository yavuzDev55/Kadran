// src/features/task/task.controller.js

import {
  getTasksService,
  createTaskService,
  updateTaskService,
  deleteTaskService,
  toggleTaskService,
  addTagsService,
  removeTagService
} from './task.service.js';

/**
 * GET /tasks - Görevleri listele (filtreleme ile)
 */
export const getTasks = async (req, res, next) => {
  try {
    const userId = req.user.sub;
    const filters = req.query;

    const result = await getTasksService(userId, filters);
    
    return res.json({
      ...result,
      userTimeZone: req.user.timeZone || 'Europe/Istanbul'
    });
  } catch (error) {
    next(error);
  }
};

/**
 * POST /tasks - Yeni görev oluştur
 * Body validasyonu: validateCreateTask middleware'i tarafından yapılır
 */
export const createTask = async (req, res, next) => {
  try {
    const userId = req.user.sub;
    const taskData = req.body;

    const task = await createTaskService(userId, taskData);
    
    return res.status(201).json(task);
  } catch (error) {
    next(error);
  }
};

/**
 * PATCH /tasks/:id - Görev güncelle
 * SADECE var olan alanları günceller (partial update)
 */
export const updateTask = async (req, res, next) => {
  try {
    const userId = req.user.sub;
    const taskId = req.params.id;
    const updateData = req.body;

    // Güncellenecek alanları filtrele (sadece izin verilen alanlar)
    const allowedFields = [
      'title',
      'description',
      'type',
      'categoryId',
      'timeType',
      'date',
      'startTime',
      'endTime',
      'reminderTime',
      'priority',
      'isRecurring',
      'recurrencePattern',
      'recurrenceDays',
      'recurrenceStart',
      'recurrenceEnd',
      'recurrenceDay'
    ];

    const filteredData = {};
    Object.keys(updateData).forEach(key => {
      if (allowedFields.includes(key)) {
        filteredData[key] = updateData[key];
      }
    });

    if (Object.keys(filteredData).length === 0) {
      return res.status(400).json({ 
        error: 'No valid fields to update',
        allowedFields 
      });
    }

    const task = await updateTaskService(userId, taskId, filteredData);
    
    return res.json(task);
  } catch (error) {
    next(error);
  }
};

/**
 * DELETE /tasks/:id - Görev sil
 */
export const deleteTask = async (req, res, next) => {
  try {
    const userId = req.user.sub;
    const taskId = req.params.id;

    await deleteTaskService(userId, taskId);
    
    return res.status(204).send();
  } catch (error) {
    next(error);
  }
};

/**
 * PATCH /tasks/:id/toggle - Tamamlama durumunu toggle et
 */
export const toggleTaskCompletion = async (req, res, next) => {
  try {
    const userId = req.user.sub;
    const taskId = req.params.id;

    const task = await toggleTaskService(userId, taskId);
    
    return res.json(task);
  } catch (error) {
    next(error);
  }
};

/**
 * POST /tasks/:id/tags - Etiketleri göreve ekle
 * Body: { "tagNames": ["tag1", "tag2"] }
 */
export const addTagsToTask = async (req, res, next) => {
  try {
    const userId = req.user.sub;
    const taskId = req.params.id;
    const { tagNames } = req.body;

    // Validasyon
    if (!tagNames || !Array.isArray(tagNames)) {
      return res.status(400).json({ 
        error: 'tagNames must be an array',
        example: { tagNames: ['tag1', 'tag2'] }
      });
    }

    if (tagNames.length === 0) {
      return res.status(400).json({ error: 'tagNames array cannot be empty' });
    }

    // Tag adlarını temizle (trim ve lowercase)
    const cleanTagNames = tagNames.map(tag => 
      String(tag).trim().toLowerCase()
    ).filter(tag => tag.length > 0);

    if (cleanTagNames.length === 0) {
      return res.status(400).json({ error: 'No valid tag names provided' });
    }

    const task = await addTagsService(userId, taskId, cleanTagNames);
    
    return res.status(201).json(task);
  } catch (error) {
    next(error);
  }
};

/**
 * DELETE /tasks/:id/tags/:tagId - Etiketi görevden çıkar
 */
export const removeTagFromTask = async (req, res, next) => {
  try {
    const userId = req.user.sub;
    const taskId = req.params.id;
    const tagId = req.params.tagId;

    await removeTagService(userId, taskId, tagId);
    
    return res.status(204).send();
  } catch (error) {
    next(error);
  }
};
// src/features/task/task.db.js

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

/**
 * Görevleri filtre ve pagination ile getir
 */
export const getTasksByUser = async (userId, options = {}) => {
  const {
    from,
    to,
    tags = [],
    category,
    priority,
    showCompleted = true,
    limit = 20,
    offset = 0
  } = options;

  // WHERE clause oluştur
  const where = {
    userId
  };

  // Tarih aralığı
  if (from || to) {
    where.date = {};
    if (from) where.date.gte = new Date(from);
    if (to) where.date.lte = new Date(to);
  }

  // Kategori filtresi
  if (category) {
    where.type = category;
  }

  // Önem filtresi
  if (priority) {
    where.priority = priority;
  }

  // Tamamlanma durumu
  if (!showCompleted) {
    where.isCompleted = false;
  }

  // Etiket filtresi (N:N)
  if (tags.length > 0) {
    where.tags = {
      some: {
        tag: {
          name: {
            in: tags
          }
        }
      }
    };
  }

  // Görevleri getir
  const tasks = await prisma.task.findMany({
    where,
    include: {
      category: true,
      tags: {
        include: { tag: true }
      }
    },
    orderBy: { date: 'asc' },
    take: limit,
    skip: offset
  });

  // Total sayısı
  const total = await prisma.task.count({ where });

  return {
    tasks,
    total,
    hasMore: offset + limit < total
  };
};

/**
 * ID'ye göre görev getir
 */
export const getTaskById = async (id) => {
  return prisma.task.findUnique({
    where: { id },
    include: {
      category: true,
      tags: {
        include: { tag: true }
      }
    }
  });
};

/**
 * Yeni görev oluştur
 */
export const createTaskInDb = async (userId, taskData) => {
  return prisma.task.create({
    data: {
      ...taskData,
      userId
    },
    include: {
      category: true,
      tags: {
        include: { tag: true }
      }
    }
  });
};

/**
 * Görev güncelle (partial update)
 */
export const updateTaskInDb = async (id, taskData) => {
  // Null değerleri kaldır (güncellenmeyecek alanlar)
  const cleanData = {};
  Object.keys(taskData).forEach(key => {
    if (taskData[key] !== undefined && taskData[key] !== null) {
      cleanData[key] = taskData[key];
    }
  });

  return prisma.task.update({
    where: { id },
    data: cleanData,
    include: {
      category: true,
      tags: {
        include: { tag: true }
      }
    }
  });
};

/**
 * Görev sil
 */
export const deleteTaskFromDb = async (id) => {
  return prisma.task.delete({
    where: { id }
  });
};

/**
 * Görev tamamlama durumunu toggle et
 */
export const toggleTaskCompletionInDb = async (id) => {
  const task = await getTaskById(id);
  
  return prisma.task.update({
    where: { id },
    data: {
      isCompleted: !task.isCompleted
    },
    include: {
      category: true,
      tags: {
        include: { tag: true }
      }
    }
  });
};

/**
 * Etiketi göreve ekle
 */
export const addTagToTask = async (taskId, tagId) => {
  return prisma.taskTag.upsert({
    where: {
      taskId_tagId: { taskId, tagId }
    },
    create: { taskId, tagId },
    update: {}
  });
};

/**
 * Etiketi görevden çıkar
 */
export const removeTagFromTaskDb = async (taskId, tagId) => {
  return prisma.taskTag.delete({
    where: {
      taskId_tagId: { taskId, tagId }
    }
  });
};
// src/features/task/task.routes.js

import express from 'express';
import {
  getTasks,
  createTask,
  updateTask,
  deleteTask,
  toggleTaskCompletion,
  addTagsToTask,
  removeTagFromTask
} from './task.controller.js';
import {
  validateCreateTask,
  validateUpdateTask,
  validateTaskId,
  validateTaskParams
} from './task.validator.js';

const router = express.Router();

// GET /tasks - Görevleri listele (filtreleme ile)
router.get('/', getTasks);

// POST /tasks - Yeni görev oluştur
router.post('/', validateCreateTask, createTask);

// PATCH /tasks/:id - Görev güncelle
router.patch('/:id', validateTaskId, validateUpdateTask, updateTask);

// DELETE /tasks/:id - Görev sil
router.delete('/:id', validateTaskId, deleteTask);

// PATCH /tasks/:id/toggle - Tamamlama durumunu toggle et
router.patch('/:id/toggle', validateTaskId, toggleTaskCompletion);

// POST /tasks/:id/tags - Etiket ekle
router.post('/:id/tags', validateTaskId, addTagsToTask);

// DELETE /tasks/:id/tags/:tagId - Etiket çıkar
router.delete('/:id/tags/:tagId', validateTaskParams, removeTagFromTask);

export default router;
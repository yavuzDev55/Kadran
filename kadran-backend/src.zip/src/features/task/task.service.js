// src/features/task/task.service.js

import {
  getTasksByUser,
  getTaskById,
  createTaskInDb,
  updateTaskInDb,
  deleteTaskFromDb,
  toggleTaskCompletionInDb,
  addTagToTask,
  removeTagFromTaskDb
} from './task.db.js';
import { PrismaClient } from '@prisma/client';
import {
  isValidTaskType,
  isValidTimeType,
  isValidTime,
  isValidTimeRange,
  isValidPriority,
  isValidRecurrencePattern,
  isValidDays
} from '../../shared/utils/validators.js';
import {
  ValidationError,
  AuthorizationError,
  NotFoundError
} from '../../shared/middlewares/error.middleware.js';

const prisma = new PrismaClient();

/**
 * Görevleri getir (Pagination + Filtreleme)
 */
export const getTasksService = async (userId, filters = {}) => {
  const options = {
    from: filters.from ? new Date(filters.from) : undefined,
    to: filters.to ? new Date(filters.to) : undefined,
    tags: filters.tags ? filters.tags.split(',').map(t => t.trim()) : [],
    category: filters.category,
    priority: filters.priority,
    showCompleted: filters.showCompleted !== 'false',
    limit: Math.min(parseInt(filters.limit) || 20, 100),
    offset: parseInt(filters.offset) || 0
  };

  return getTasksByUser(userId, options);
};

/**
 * Yeni görev oluştur
 */
export const createTaskService = async (userId, taskData) => {
  const {
    title,
    description,
    type,
    categoryId,
    timeType,
    date,
    startTime,
    endTime,
    reminderTime,
    priority,
    isRecurring,
    recurrencePattern,
    recurrenceDays,
    recurrenceStart,
    recurrenceEnd,
    recurrenceDay,
    tags = []
  } = taskData;

  // Kategori ownership kontrol
  const category = await prisma.category.findUnique({
    where: { id: parseInt(categoryId) }
  });

  if (!category || category.userId !== userId) {
    throw new NotFoundError('Category', categoryId);
  }

  // Task oluştur
  const taskPayload = {
    title,
    description,
    type,
    categoryId: parseInt(categoryId),
    timeType,
    date: new Date(date),
    startTime: timeType === 'HOURLY' ? startTime : null,
    endTime: timeType === 'HOURLY' ? endTime : null,
    reminderTime: timeType === 'REMINDER' ? reminderTime : null,
    priority: priority || 'MEDIUM',
    isRecurring: isRecurring || false
  };

  // Tekrarlama alanları
  if (isRecurring) {
    taskPayload.recurrencePattern = recurrencePattern;
    taskPayload.recurrenceStart = recurrenceStart ? new Date(recurrenceStart) : new Date(date);
    taskPayload.recurrenceEnd = recurrenceEnd ? new Date(recurrenceEnd) : null;
    if (recurrencePattern === 'WEEKLY') {
      taskPayload.recurrenceDays = recurrenceDays;
    }
    if (recurrencePattern === 'MONTHLY') {
      taskPayload.recurrenceDay = recurrenceDay;
    }
  }

  const task = await createTaskInDb(userId, taskPayload);

  // Etiketleri ekle
  if (tags && tags.length > 0) {
    await addTagsService(userId, task.id, tags);
  }

  return getTaskById(task.id);
};

/**
 * Görev güncelle
 * PATCH ile sadece verilen alanları günceller
 */
export const updateTaskService = async (userId, taskId, updateData) => {
  // Görev var mı ve sahibi mi?
  const task = await getTaskById(taskId);
  if (!task || task.userId !== userId) {
    throw new AuthorizationError('You can only update your own tasks');
  }

  // Eğer categoryId değişiyorsa kontrol et
  if (updateData.categoryId) {
    const category = await prisma.category.findUnique({
      where: { id: parseInt(updateData.categoryId) }
    });

    if (!category || category.userId !== userId) {
      throw new NotFoundError('Category', updateData.categoryId);
    }
  }

  // Date'i parse et (eğer varsa)
  const processedData = { ...updateData };
  if (processedData.date) {
    processedData.date = new Date(processedData.date);
  }

  // Recurrence start/end'i parse et
  if (processedData.recurrenceStart) {
    processedData.recurrenceStart = new Date(processedData.recurrenceStart);
  }
  if (processedData.recurrenceEnd) {
    processedData.recurrenceEnd = new Date(processedData.recurrenceEnd);
  }

  // Kategori ID'yi integer'a çevir
  if (processedData.categoryId) {
    processedData.categoryId = parseInt(processedData.categoryId);
  }

  return updateTaskInDb(taskId, processedData);
};

/**
 * Görev sil
 */
export const deleteTaskService = async (userId, taskId) => {
  const task = await getTaskById(taskId);
  if (!task || task.userId !== userId) {
    throw new AuthorizationError('You can only delete your own tasks');
  }

  await deleteTaskFromDb(taskId);
  return true;
};

/**
 * Görev tamamlama toggle
 */
export const toggleTaskService = async (userId, taskId) => {
  const task = await getTaskById(taskId);
  if (!task || task.userId !== userId) {
    throw new AuthorizationError('You can only toggle your own tasks');
  }

  return toggleTaskCompletionInDb(taskId);
};

/**
 * Etiketleri göreve ekle
 */
export const addTagsService = async (userId, taskId, tagNames) => {
  // Görev ownership kontrol
  const task = await getTaskById(taskId);
  if (!task || task.userId !== userId) {
    throw new AuthorizationError('You can only add tags to your own tasks');
  }

  for (const tagName of tagNames) {
    // Tag var mı, yoksa oluştur
    let tag = await prisma.tag.findFirst({
      where: { name: tagName, userId }
    });

    if (!tag) {
      tag = await prisma.tag.create({
        data: { name: tagName, userId }
      });
    }

    // TaskTag ekle
    await addTagToTask(taskId, tag.id);
  }

  return getTaskById(taskId);
};

/**
 * Etiketi görevden çıkar
 */
export const removeTagService = async (userId, taskId, tagId) => {
  // Görev ownership kontrol
  const task = await getTaskById(taskId);
  if (!task || task.userId !== userId) {
    throw new AuthorizationError('You can only remove tags from your own tasks');
  }

  await removeTagFromTaskDb(taskId, tagId);
  return true;
};
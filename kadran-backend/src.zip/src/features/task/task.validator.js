// src/features/task/task.validator.js

import {
  isValidTaskType,
  isValidTimeType,
  isValidTime,
  isValidTimeRange,
  isValidPriority
} from '../../shared/utils/validators.js';
import { ValidationError } from '../../shared/middlewares/error.middleware.js';

/**
 * Yeni görev oluşturma validasyonu
 */
export const validateCreateTask = (req, res, next) => {
  const {
    title,
    type,
    timeType,
    date,
    categoryId,
    startTime,
    endTime,
    reminderTime,
    priority
  } = req.body;

  const errors = [];

  // Title validasyonu
  if (!title || title.trim() === '') {
    errors.push('Title is required');
  }
  if (title && title.length > 255) {
    errors.push('Title must be 255 characters or less');
  }

  // Type validasyonu
  if (!type) {
    errors.push('Type is required');
  }
  if (type && !isValidTaskType(type)) {
    errors.push('Type must be one of: DERS, SINAV, ODEV, KISISEL');
  }

  // TimeType validasyonu
  if (!timeType) {
    errors.push('TimeType is required');
  }
  if (timeType && !isValidTimeType(timeType)) {
    errors.push('TimeType must be one of: HOURLY, ALLDAY, REMINDER');
  }

  // Date validasyonu
  if (!date) {
    errors.push('Date is required');
  }
  if (date) {
    const dateObj = new Date(date);
    if (isNaN(dateObj.getTime())) {
      errors.push('Invalid date format');
    }
  }

  // Category ID validasyonu
  if (!categoryId) {
    errors.push('CategoryId is required');
  }
  if (categoryId && !Number.isInteger(Number(categoryId))) {
    errors.push('CategoryId must be an integer');
  }

  // TimeType bazlı validasyonlar
  if (timeType === 'HOURLY') {
    if (!startTime || !endTime) {
      errors.push('startTime and endTime are required for HOURLY tasks');
    }
    if (startTime && !isValidTime(startTime)) {
      errors.push('startTime must be in HH:MM format (e.g., 09:00)');
    }
    if (endTime && !isValidTime(endTime)) {
      errors.push('endTime must be in HH:MM format (e.g., 11:00)');
    }
    if (startTime && endTime && !isValidTimeRange(startTime, endTime)) {
      errors.push('startTime must be before endTime');
    }
  }

  if (timeType === 'REMINDER') {
    if (!reminderTime) {
      errors.push('reminderTime is required for REMINDER tasks');
    }
    if (reminderTime && !isValidTime(reminderTime)) {
      errors.push('reminderTime must be in HH:MM format (e.g., 08:00)');
    }
  }

  // Priority validasyonu
  if (priority && !isValidPriority(priority)) {
    errors.push('Priority must be one of: LOW, MEDIUM, HIGH');
  }

  if (errors.length > 0) {
    const error = new ValidationError('Task validation failed', { errors });
    return next(error);
  }

  next();
};

/**
 * Görev güncelleme validasyonu
 */
export const validateUpdateTask = (req, res, next) => {
  const {
    title,
    type,
    timeType,
    date,
    categoryId,
    startTime,
    endTime,
    reminderTime,
    priority
  } = req.body;

  const errors = [];

  // Title (optional ama validasyon yapılabilir)
  if (title !== undefined) {
    if (title.trim() === '') {
      errors.push('Title cannot be empty');
    }
    if (title.length > 255) {
      errors.push('Title must be 255 characters or less');
    }
  }

  // Type (optional)
  if (type && !isValidTaskType(type)) {
    errors.push('Type must be one of: DERS, SINAV, ODEV, KISISEL');
  }

  // TimeType (optional)
  if (timeType && !isValidTimeType(timeType)) {
    errors.push('TimeType must be one of: HOURLY, ALLDAY, REMINDER');
  }

  // Date (optional)
  if (date) {
    const dateObj = new Date(date);
    if (isNaN(dateObj.getTime())) {
      errors.push('Invalid date format');
    }
  }

  // TimeType bazlı validasyonlar (update için)
  if (timeType === 'HOURLY' || (startTime && endTime)) {
    if (startTime && !isValidTime(startTime)) {
      errors.push('startTime must be in HH:MM format (e.g., 09:00)');
    }
    if (endTime && !isValidTime(endTime)) {
      errors.push('endTime must be in HH:MM format (e.g., 11:00)');
    }
    if (startTime && endTime && !isValidTimeRange(startTime, endTime)) {
      errors.push('startTime must be before endTime');
    }
  }

  if (timeType === 'REMINDER' || reminderTime) {
    if (reminderTime && !isValidTime(reminderTime)) {
      errors.push('reminderTime must be in HH:MM format (e.g., 08:00)');
    }
  }

  // Priority (optional)
  if (priority && !isValidPriority(priority)) {
    errors.push('Priority must be one of: LOW, MEDIUM, HIGH');
  }

  if (errors.length > 0) {
    const error = new ValidationError('Task update validation failed', { errors });
    return next(error);
  }

  next();
};

/**
 * Task ID validasyonu
 */
export const validateTaskId = (req, res, next) => {
  const { id } = req.params;

  if (!id) {
    const error = new ValidationError('Task ID is required');
    return next(error);
  }

  const taskId = parseInt(id);
  if (isNaN(taskId) || taskId <= 0) {
    const error = new ValidationError('Task ID must be a positive integer');
    return next(error);
  }

  // Sonraki handler için id'yi parse edilmiş olarak sakla
  req.params.id = taskId;
  next();
};

/**
 * Task params validasyonu (id ve tagId)
 */
export const validateTaskParams = (req, res, next) => {
  const { id, tagId } = req.params;

  const errors = [];

  if (!id) {
    errors.push('Task ID is required');
  } else {
    const taskId = parseInt(id);
    if (isNaN(taskId) || taskId <= 0) {
      errors.push('Task ID must be a positive integer');
    }
  }

  if (!tagId) {
    errors.push('Tag ID is required');
  } else {
    const tid = parseInt(tagId);
    if (isNaN(tid) || tid <= 0) {
      errors.push('Tag ID must be a positive integer');
    }
  }

  if (errors.length > 0) {
    const error = new ValidationError('Invalid parameters', { errors });
    return next(error);
  }

  req.params.id = parseInt(id);
  req.params.tagId = parseInt(tagId);
  next();
};
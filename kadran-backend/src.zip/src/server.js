// src/server.js

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

// Routes
import authRoutes from './features/auth/auth.routes.js';
import taskRoutes from './features/task/task.routes.js';
import categoryRoutes from './features/category/category.routes.js';
import tagRoutes from './features/tag/tag.routes.js';

// Middlewares
import { authMiddleware } from './shared/middlewares/auth.middleware.js';
import { errorHandler } from './shared/middlewares/error.middleware.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// ============ MIDDLEWARES ============

// Body parser
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true
}));

// ============ HEALTH CHECK ============

app.get('/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'KADRAN Backend is running',
    timestamp: new Date().toISOString()
  });
});

// ============ PUBLIC ROUTES (Auth) ============

app.post('/auth/register', authRoutes);
app.post('/auth/login', authRoutes);

// ============ PROTECTED ROUTES (Auth Required) ============

// Auth middleware'ını uygula
app.use(authMiddleware);

// Task routes
app.use('/tasks', taskRoutes);

// Category routes
app.use('/categories', categoryRoutes);

// Tag routes
app.use('/tags', tagRoutes);

// ============ 404 HANDLER ============

app.use((req, res) => {
  res.status(404).json({ 
    error: 'Route not found',
    path: req.path,
    method: req.method
  });
});

// ============ ERROR HANDLER (En sonunda!) ============

app.use(errorHandler);

// ============ SERVER START ============

app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║         ✅  KADRAN Backend Server Started                  ║
║                                                            ║
║  🚀 http://localhost:${PORT}                                ║
║  📝 API Docs: http://localhost:${PORT}/health              ║
║  🗄️  Database: ${process.env.DATABASE_URL?.split('@')[1] || 'Not Set'}
║  🌍 CORS Origin: ${process.env.FRONTEND_URL || 'http://localhost:3000'}
║                                                            ║
╚════════════════════════════════════════════════════════════╝
  `);
});
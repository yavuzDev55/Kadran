// src/shared/middlewares/auth.middleware.js

import jwt from 'jsonwebtoken';

export const authMiddleware = (req, res, next) => {
  try {
    // Authorization header'dan token al
    const token = req.headers.authorization?.split(' ')[1];

    if (!token) {
      return res.status(401).json({ error: 'Token required' });
    }

    // Token'ı verify et
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // req.user'a ekle
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
};